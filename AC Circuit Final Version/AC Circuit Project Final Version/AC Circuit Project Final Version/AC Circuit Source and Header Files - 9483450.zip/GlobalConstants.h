#pragma once
//Value of pi
const double pi{ 3.14159265359 };